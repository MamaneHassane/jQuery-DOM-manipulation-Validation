$(document).ready(function() {
$("#bt1").click(function(){ 
    if((typeof pnom=="undefined"))
    $("#target").append('<tr><td>Prenom:</td><td><input type="text" id="pnom"></td></tr>')
    else alert("Prenom deja ajoute");
});
$("#bt2").click(function(){ 
    if((typeof email=="undefined"))
    $("#target").append('<tr><td>Email:</td><td><input type="text" id="email"></td></tr>')
    else alert("Email deja ajoutee");
});
$("#bt3").click(function(){ 
    var today = new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();  
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();   
    const Ladate="La date est: " + date + " et il est: " +time ;
    $("#tete").append('<p id="dt"></p>');
    $("#dt").append(Ladate);
});
$("#bt4").click(function(){ 
    $("#dt").remove();
});
$("#submit").click(function() {
if((typeof nom!="undefined"))
{
    var Nom = $('#nom').val();
    var test_nom = /^[A-Za-z]+( [A-Za-z]+)*$/g;
    if (Nom.length == 0) {
    if(typeof p1 !== "undefined") $("#p1").remove();
    $("#target").prepend('<p id="p1"></p>');
    $("#p1").text("Remplir nom");
    $("#Nom").focus();
    }
    else if (Nom.length != 0 && !Nom.match(test_nom)){
    if(typeof p1 !== "undefined") $("#p1").remove();
    $("#target").prepend('<p id="p1"></p>');
    $("#p1").text("Un probleme dans le nom");
    $("#Nom").focus();
    }
    else
    {
    if(typeof p1 !== "undefined") $("#p1").remove();
    $("#target").prepend('<p id="p1"></p>');
    $("#p1").text("Nom valide");
    }
}
if((typeof pnom!="undefined"))
{
    var Prenom = $('#pnom').val();
    var test_nom = /^[A-Za-z]+( [A-Za-z]+)*$/g;
    if (Prenom.length == 0) {
    if(typeof p2 !== "undefined") $("#p2").remove();
    $("#target").prepend('<p id="p2"></p>');
    $("#p2").text("Remplir prenom");
    $("#Prenom").focus();
    }
    else if (Prenom.length != 0 && !Prenom.match(test_nom)){
    if(typeof p2 !== "undefined") $("#p2").remove();
    $("#target").prepend('<p id="p2"></p>');
    $("#p2").text("Un probleme dans le prenom");
    $("#Prenom").focus();
    }
    else
    {
    if(typeof p2 !== "undefined") $("#p2").remove();
    $("#target").prepend('<p id="p2"></p>');
    $("#p2").text("Prenom valide");
    }
}

if((typeof email!="undefined"))
{
    var Email = $('#email').val();
    var test_email =/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if (Email.length == 0) {
    if(typeof p3 !== "undefined") $("#p3").remove();
    $("#target").prepend('<p id="p3"></p>');
    $("#p3").text("Remplir email");
    $("#Email").focus();
    }
    else if (Email.length != 0 && !Email.match(test_email)){
    if(typeof p3 !== "undefined") $("#p3").remove();
    $("#target").prepend('<p id="p3"></p>');
    $("#p3").text("Un probleme dans l'email");
    $("#Email").focus();
    }
    else
    {
    if(typeof p3 !== "undefined") $("#p3").remove();
    $("#target").prepend('<p id="p3"></p>');
    $("#p3").text("Email valide");
    }
}
});
});